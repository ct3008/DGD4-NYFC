using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireGun : MonoBehaviour
{
    // private void OnTriggerEnter2D(Collider2D collider)
    // {
    //     if (collider.name == "Player")
    //     {
    //         if (raycast != null)
    //         {
    //             raycast.CastRays(true); // Call the CastRays function from the Raycast script
    //         }
    //         else
    //         {
    //             Debug.LogWarning("Raycast reference is not set in FireGun script.");
    //         }
    //     }
    // }
}
