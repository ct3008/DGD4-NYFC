using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArmPivot : MonoBehaviour
{
    public GameObject myPlayer;
    
    private void FixedUpdate(){
        Vector3 difference = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position; //convert screen position to world position
        difference.Normalize();
        float rotationZ = Mathf.Atan2(difference.y, difference.x) * Mathf.Rad2Deg;

        transform.rotation = Quaternion.Euler(0f, 0f, rotationZ);

        if (rotationZ < -90 || rotationZ > 90) {
            //negative myPlayer.transform.localScale.x means pointing right, pos means left
            if (myPlayer.transform.localScale.x > 0) {
                //pointing left which is the natural location
                transform.localRotation = Quaternion.Euler(180,0,-rotationZ);
            } else if (myPlayer.transform.localScale.x < 0){
                //facing right 
                //player facing dir not naturally facing. Don't allow the arm to follow body rotation. Keep pointed at mouse
                transform.localRotation = Quaternion.Euler(180,0,-rotationZ);
            }
        }

    }
}
