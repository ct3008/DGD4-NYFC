using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    [SerializeField] private float spawnRate = 1f;
    [SerializeField] private GameObject[] enemyPrefabs;

    public Transform player;
    private void Start(){
        StartCoroutine(Spawner());
        
    }

    private IEnumerator Spawner () {
        WaitForSeconds wait = new WaitForSeconds(spawnRate);

        while(true){
            yield return wait; //pauses while loop every spawn rate interval
            //randomly choose type of enemy to spawn
            int rand = Random.Range(0, enemyPrefabs.Length);
            GameObject enemyToSpawn = enemyPrefabs[rand];
            
            Instantiate(enemyToSpawn, transform.position, Quaternion.identity);
        }
    }

    private void Update() {
        //updates location of spawners to follow player movement
        if(gameObject.CompareTag("Bottom")){
            transform.position = new Vector3(player.position.x, player.position.y - 30f, transform.position.z);
        }else if (gameObject.CompareTag("Top")){
            transform.position = new Vector3(player.position.x, player.position.y + 30f, transform.position.z);
        }else if (gameObject.CompareTag("Right")){
            transform.position = new Vector3(player.position.x + 30f, player.position.y, transform.position.z);
        }else if (gameObject.CompareTag("Left")){
            transform.position = new Vector3(player.position.x - 30f, player.position.y, transform.position.z);
        }
    }


}
