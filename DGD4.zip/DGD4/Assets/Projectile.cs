using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    public float projectileSpeed = 20.0f;
    public GameObject impactEffect;
    private Rigidbody2D rb;
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        Vector3 difference = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position; //convert screen pos of mouse to world (in game) position minus transform pos of arm pivot
        difference.Normalize(); //bw 0 and 1
        float rotationZ = Mathf.Atan2(difference.y, difference.x) * Mathf.Rad2Deg;
        
        rb.velocity = Quaternion.Euler(0f, 0f, rotationZ) * Vector2.right * projectileSpeed;
    }

    private void OnTriggerEnter2D(Collider2D collider) {
        if (collider.CompareTag("Chicken")){
            Destroy(gameObject);
        }
        
    }
}
