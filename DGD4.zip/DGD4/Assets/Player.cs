using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    [SerializeField] float health, maxHealth = 20f;
    [SerializeField] FloatingHealthBar healthBar;

    public GameObject chicken;
    public GameObject turkey;

    private SpawnAndDespawn spawnAndDespawn;

    private void Awake(){
        healthBar = GetComponentInChildren<FloatingHealthBar>();
        spawnAndDespawn = FindObjectOfType<SpawnAndDespawn>();
    }

    private void Start()
    {
        health = maxHealth;
        healthBar.UpdateHealthBar(health, maxHealth);
    }

    public void TakeDamage(float damageAmount)
    {
        health -= damageAmount;
        healthBar.UpdateHealthBar(health, maxHealth);
        if (health <= 0)
        {
            //Health is less than 0, reset the game and reset speed of enemies
            Enemy chick = chicken.GetComponent<Enemy>();
            Enemy turk = turkey.GetComponent<Enemy>();
            if (chick != null && turk != null)
            {
                chick.ResetSpeed(); // Increase move speed by 3
                turk.ResetSpeed();
            }
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    public void MakeHeal(float healAmount)
    {
        //Heal health
        health += healAmount;
        health = Mathf.Clamp(health,0, maxHealth);
        healthBar.UpdateHealthBar(health, maxHealth);
    }

    public void CallSpawn(string name, Vector3 position, Quaternion rotation){
        //In control of the logic to spawn and despawn the loot
        spawnAndDespawn.SpawnPrefab(name, position, rotation);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Take damage if enemy collides with player and if it's food, heal the player and set the food to inactive
        if (other.CompareTag("Chicken"))
        {
            // Damage the chicken by 2 points
            TakeDamage(2f);
        }

        if (other.CompareTag("Food")){
            MakeHeal(3f);
            other.gameObject.SetActive(false);
            
        }
    }

    
}
