using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttack : MonoBehaviour
{

    public Transform firePosition;  //stores position and rotation
    public GameObject projectile;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0)){//left mouse
            Instantiate(projectile, firePosition.position, firePosition.rotation);
        }
        //get input from player to shoot
        //spawn a projectile
            //where to spawn projectile
        
    }
}
