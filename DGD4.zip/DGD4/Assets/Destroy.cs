using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroy : MonoBehaviour
{

    private GameObject player;
    void Start(){
        player = GameObject.Find("Player");
    }
    private void OnTriggerEnter2D(Collider2D collider){
        //Destroy anything interacting with destroyer
        Destroy(collider.gameObject);
    }


    void Update()
    {
        //Destroyers follow player's movements
        if(gameObject.CompareTag("Bottom")){
            transform.position = new Vector3(player.transform.position.x, player.transform.position.y - 60f, transform.position.z);
        }else if (gameObject.CompareTag("Top")){
            transform.position = new Vector3(player.transform.position.x, player.transform.position.y + 60f, transform.position.z);
        }else if (gameObject.CompareTag("Right")){
            transform.position = new Vector3(player.transform.position.x + 60f, player.transform.position.y, transform.position.z);
        }else if (gameObject.CompareTag("Left")){
            transform.position = new Vector3(player.transform.position.x - 60f, player.transform.position.y, transform.position.z);
        }
        

    }


}

