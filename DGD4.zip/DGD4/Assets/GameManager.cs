using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    private int points = 0;
    private int highscore = 0;
    public Text scoreText; // Reference to the Text component for displaying the score

    // Static instance for easy access
    public static GameManager instance;

    public GameObject chicken; 
    public GameObject turkey;

    private void Awake()
    {
        // Singleton pattern to ensure only one instance of GameManager exists
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }

        Enemy chickEnemy = chicken.GetComponentInChildren<Enemy>();
        Enemy turkEnemy = turkey.GetComponentInChildren<Enemy>();

        if (chickEnemy != null && turkEnemy != null)
        {
            chickEnemy.ResetSpeed();
            turkEnemy.ResetSpeed();
        }
        
    }

    private void Start()
    {
        // Find the Text component if not set
        if (scoreText == null)
        {
            scoreText = GameObject.Find("Score").GetComponent<Text>(); 
        }

        
        // Load the highscore from PlayerPrefs
        LoadHighscore();

        UpdateScoreText();
    }

    public void AddPoints(int amount)
    {
        points += amount;
        if (points > highscore)
        {
            highscore = points;
            // Save the new highscore to PlayerPrefs
            SaveHighscore();
        }

        // Check if points reached a multiple of 15
        if (points % 15 == 0)
        {
            IncreaseEnemyMoveSpeed();
        }

        UpdateScoreText();
    }

    private void UpdateScoreText()
    {
        if (scoreText != null)
        {
            scoreText.text = string.Format("Score: {0}\nHighscore: {1}", points, highscore);
        }
        else
        {
            Debug.LogWarning("Score not set in the GameManager.");
        }
    }

    private void SaveHighscore()
    {
        PlayerPrefs.SetInt("Highscore", highscore);
        PlayerPrefs.Save();
    }

    private void LoadHighscore()
    {
        if (PlayerPrefs.HasKey("Highscore"))
        {
            highscore = PlayerPrefs.GetInt("Highscore");
        }
    }

    private void IncreaseEnemyMoveSpeed()
    {
        // Get the Enemy component of the prefab and increase its move speed
        Enemy chick = chicken.GetComponent<Enemy>();
        Enemy turk = turkey.GetComponent<Enemy>();
        if (chick != null && turk != null)
        {
            chick.IncreaseMoveSpeed(1f); 
            turk.IncreaseMoveSpeed(1f);
        }
    }
}
