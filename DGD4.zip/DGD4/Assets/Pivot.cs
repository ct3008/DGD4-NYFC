using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pivot : MonoBehaviour
{
    public GameObject myPlayer;
    void FixedUpdate()
    {
        // Vector3 difference = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;

        // difference.Normalize();

        // float rotationZ = Mathf.Atan2(difference.y, difference.x) * Mathf.Rad2Deg;

        // Quaternion currentRotation = transform.rotation;

        // currentRotation.eulerAngles = new Vector3(currentRotation.eulerAngles.x, currentRotation.eulerAngles.y, rotationZ);

        // transform.rotation = currentRotation;
    }
}
