using UnityEngine;
using System.Collections;

public class Raycast : MonoBehaviour
{
    public float rotationSpeed = 240f; // Speed of rotation
    public float rayDistance; // Max distance for the ray

    private float currentAngle = 0f; // Current angle of the ray

    private bool gunShoot = false;
    private Transform playerTransform; // player's transform

    public LineRenderer lineRenderer; // To draw line

    

    void FixedUpdate()
    {
        RotateRaycast();
        CastRay();

        if (gunShoot && playerTransform != null)
        {
            //make Gun follow player
            transform.position = playerTransform.position; 
        }
    }

    void RotateRaycast()
    {
        currentAngle += rotationSpeed * Time.fixedDeltaTime;
        currentAngle %= 360f;
    }

    void CastRay()
    {
        Vector2 direction = new Vector2(Mathf.Cos(currentAngle * Mathf.Deg2Rad), Mathf.Sin(currentAngle * Mathf.Deg2Rad));

        LayerMask layerMask = LayerMask.GetMask("Enemies");
        if (gunShoot)
        {
            //if raycast is on the gun and it's active, distance of raycast is 12f
            rayDistance = 12f;
        }
        else
        {
            rayDistance = 30f;
        }

        RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, rayDistance, layerMask);

        if (hit.collider != null && (hit.collider.name.Contains("Chicken") || hit.collider.name.Contains("Turkey")))
        {
            Enemy enemy = hit.collider.GetComponent<Enemy>();
            if (enemy != null)
            {
                if (gunShoot)
                {
                    enemy.TakeDamage(20f);//ensure death on first hit
                    //maybe initialize bullet and shoot here
                }
                else
                {
                    //if raycast is on the player, once ray hits an enemy, allow enemy to start tracking player
                    enemy.StartTrackingPlayer();
                }
            }
        }

        if(lineRenderer != null && gameObject.name != "Player"){
            //For gun, draw a line to demonstrate what it's hitting
            if (gunShoot)
            {
                lineRenderer.enabled = true;
                lineRenderer.SetPosition(0, transform.position);
                lineRenderer.SetPosition(1, hit.point);
            }
            else
            {
                lineRenderer.enabled = false;
                lineRenderer.SetPosition(0, transform.position);
                lineRenderer.SetPosition(1, transform.position);
        }
        }
        

        Debug.DrawRay(transform.position, direction * rayDistance, Color.red);
    }

    private void OnTriggerEnter2D(Collider2D collider)
    {
        //Raycast is on gun and player collides with it = set active
        if (gameObject.name.Contains("FireGun") && collider.name == "Player")
        {
            gunShoot = true;
            playerTransform = collider.transform; // Follow player
            StartCoroutine(ResetGunShoot());
        }
    }

    IEnumerator ResetGunShoot()
    {
        yield return new WaitForSeconds(15f); // Wait for 10 seconds
        gunShoot = false;
        gameObject.SetActive(false);
    }
}
