using System.Collections;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField] float health, maxHealth = 10f;
    [SerializeField] FloatingHealthBar healthBar;

    [SerializeField] float moveSpeed = 3f;

    GameManager gameManager;

    Rigidbody2D rb;
    Transform target;

    Vector2 moveDirection;

    public GameObject death;
    public GameObject gun;
    public GameObject shield;

    bool isFrozen = false;

    bool start_track = false;

    private float dropType;
    float detectionRange = 30f; // Range within which the enemy detects the player

    private SpriteRenderer spriteRenderer;

    AudioManager audioManager;


    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        healthBar = GetComponentInChildren<FloatingHealthBar>();
        gameManager = FindObjectOfType<GameManager>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        audioManager = GameObject.FindGameObjectWithTag("Audio").GetComponent<AudioManager>();
    }

    private void Start()
    {
        health = maxHealth;
        healthBar.UpdateHealthBar(health, maxHealth);
        target = GameObject.Find("Player").transform;
        
    }


    public void TakeDamage(float damageAmount)
    {
        Player player = FindObjectOfType<Player>();
        health -= damageAmount;
        healthBar.UpdateHealthBar(health, maxHealth);
        if (health <= 0)
        {
            audioManager.PlaySFX(audioManager.death);
            Destroy(gameObject);
            gameManager.AddPoints(1);
            dropType = Random.Range(0f, 2f);
            //nothing (0 - 1.3), health pack(1.3-1.8), kill all(1.8-1.9), force field(1.9-2)?
            if (dropType >= 1.3f && dropType < 1.8f)
            {
                // Debug.Log(death.name);

                player.CallSpawn(death.name, new Vector3(transform.position.x, transform.position.y, transform.position.z), Quaternion.identity);

                // spawnAndDespawn.SpawnPrefab("death");
                // obj = Instantiate(death, new Vector3(transform.position.x, transform.position.y, transform.position.z), Quaternion.identity);
            }
            else if (dropType >= 1.8f && dropType < 1.9f)
            {
                // Debug.Log("drop gun");
                player.CallSpawn("gun", new Vector3(transform.position.x, transform.position.y, transform.position.z), Quaternion.identity);
                // spawnAndDespawn.SpawnPrefab("gun", new Vector3(transform.position.x, transform.position.y, transform.position.z), Quaternion.identity);
                // obj = Instantiate(gun, new Vector3(transform.position.x, transform.position.y, transform.position.z), Quaternion.identity);
            }
            else if (dropType >= 1.9f && dropType <= 2.0f)
            {
                // Debug.Log("drop shield");
                player.CallSpawn("shield", new Vector3(transform.position.x, transform.position.y, transform.position.z), Quaternion.identity);
                // spawnAndDespawn.SpawnPrefab("shield", new Vector3(transform.position.x, transform.position.y, transform.position.z), Quaternion.identity);
                // obj = Instantiate(shield, new Vector3(transform.position.x, transform.position.y, transform.position.z), Quaternion.identity);
            }

        
            
        }
    }


    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("boom"))
        {
            //Take damage from fireball
            TakeDamage(3f);
        }
        if (other.CompareTag("player"))
        {
            //Bump away enemy from the player + freeze motion for a second
            Vector2 awayDirection = (transform.position - other.transform.position).normalized;

            Vector2 directionAwayFromPlayer = (transform.position - other.transform.position).normalized;
            transform.position += new Vector3(directionAwayFromPlayer.x, directionAwayFromPlayer.y) * 5f;

            StartCoroutine(FreezeMotionForSeconds(1f));
        }
        if (other.gameObject.name.Contains("shield"))
        {
            //Shield bounces away enemies
            Shield shield = other.GetComponent<Shield>();
            // Check here that the shield is activated/on the player first off
            if (shield.isFollowingPlayer ){
                Vector2 directionAwayFromPlayer = (transform.position - other.transform.position).normalized;
                transform.position += new Vector3(directionAwayFromPlayer.x, directionAwayFromPlayer.y) * 5f;
            }
            
        }
    }

    public void StartTrackingPlayer()
    {
        start_track = true;
    }

    IEnumerator FreezeMotionForSeconds(float duration)
    {
        rb.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezePositionY;
        isFrozen = true;

        yield return new WaitForSeconds(duration);

        rb.constraints = RigidbodyConstraints2D.None;
        isFrozen = false;
    
        
        
    }

    private void Update()
    {
       
        if (!isFrozen && target && start_track)
        {
            // Distance between enemy and player
            float distanceToPlayer = Vector2.Distance(transform.position, target.position);
            target = GameObject.Find("Player").transform;
            // Check if player/target is within the detection range
            if (distanceToPlayer <= detectionRange)
            {
                // Move towards the player if yes
                transform.position = Vector2.MoveTowards(transform.position, target.position, moveSpeed * Time.deltaTime);

                // Flip the enemy sprite based on movement direction
                if (transform.position.x < target.position.x)
                {
                    spriteRenderer.flipX = true; // Facing left
                }
                else
                {
                    spriteRenderer.flipX = false; // Facing right
                }
            }
        }

        

    }

    //functions to access outside of here to conditionally increase speed of enemy or reset it
    public void IncreaseMoveSpeed(float amount)
    {
        moveSpeed += amount;
    }

    public void ResetSpeed()
    {
        moveSpeed = 3f;
    }

    
}
