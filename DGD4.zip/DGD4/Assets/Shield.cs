using UnityEngine;
using System.Collections;

public class Shield : MonoBehaviour
{
    private Vector3 initialScale;
    public bool isFollowingPlayer = false;
    private Player player;

    private void Start()
    {
        initialScale = transform.localScale;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("player"))
        {
            player = other.GetComponent<Player>();
            
            if (player != null)
            {
                isFollowingPlayer = true; // make the shield follow the player
                // Increase the scale of the shield
                transform.localScale = initialScale * 5f;
                

                // Coroutine to disable the shield after 10 seconds
                StartCoroutine(DisableShieldAfterDelay(15f));
            }
        }
    }

    private IEnumerator DisableShieldAfterDelay(float delay)
    {
        // Wait
        yield return new WaitForSeconds(delay);
        isFollowingPlayer = false; //Deactivate follow feature
        
        // Disable
        transform.localScale = initialScale;
        gameObject.SetActive(false);
    }

    private void Update()
    {
        if (isFollowingPlayer && player != null)
        {
            // Update position of the shield to follow the player
            transform.position = player.transform.position;
        }
    }
}
