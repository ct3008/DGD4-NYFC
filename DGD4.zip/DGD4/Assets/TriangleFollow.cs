using UnityEngine;

public class TriangleFollow : MonoBehaviour
{

    private Vector3 mousePosition; // Mouse position in world coordinates

    void Update()
    {
        //Follow mouse position with a prefab or image and update it to move it along
        mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector3 direction = mousePosition;
        direction.z = 0f;
        transform.position = direction;
    }

    
}
