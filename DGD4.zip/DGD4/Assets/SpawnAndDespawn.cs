using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnAndDespawn : MonoBehaviour
{
    public GameObject prefabToSpawn;
    public GameObject dead1;
    public GameObject dead2;
    public GameObject gun;
    public GameObject shield;
    public float spawnDelay = 1f; 
    public float despawnDelay = 20f;

    private GameObject spawnedPrefab; 
    
    public void SpawnPrefab(string type, Vector3 position, Quaternion rotation)
    {
        if (type == "Dead1"){
            prefabToSpawn = dead1;
        }else if (type == "Dead2"){
            prefabToSpawn = dead2;
        }else if (type == "gun"){
            prefabToSpawn = gun;
        }else if (type == "shield"){
            prefabToSpawn = shield;
        }

        if (prefabToSpawn != null && spawnedPrefab == null)
        {
            
            GameObject newPrefab = Instantiate(prefabToSpawn, position, rotation);

            // Coroutine to despawn the prefab after delay
            StartCoroutine(DespawnPrefabCoroutine(newPrefab));
    
            // // Instantiate the prefab at the current position with no rotation
            // spawnedPrefab = Instantiate(prefabToSpawn, transform.position, Quaternion.identity);

            // // Start the coroutine to despawn the prefab after a delay
            // StartCoroutine(DespawnPrefabCoroutine());
        }
    }

    // Despawn the prefab
    void DespawnPrefab()
    {
        if (spawnedPrefab != null)
        {
            Destroy(spawnedPrefab);
            spawnedPrefab = null;
        }
    }

    // Coroutine to despawn the prefab
    IEnumerator DespawnPrefabCoroutine(GameObject spawnedPrefab)
    {
        // Wait
        yield return new WaitForSeconds(despawnDelay);

        if(spawnedPrefab && spawnedPrefab.activeSelf){
            //Blink
            for (int i = 0; i < 5; i++)
            {
                spawnedPrefab.SetActive(false);
                yield return new WaitForSeconds(0.3f);
                spawnedPrefab.SetActive(true);
                yield return new WaitForSeconds(0.3f);
            }
            spawnedPrefab.SetActive(false);
            DespawnPrefab();
        }
        
    }

    
}
