using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed;
    private Rigidbody2D rb;
    private Vector2 moveDirection;
    private Transform playerTransform;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        playerTransform = transform;
    }

    void Update()
    {
        ProcessInputs();
        FlipPlayer();
    }

    void FixedUpdate()
    {
        Move();
    }

    void ProcessInputs()
    {
        float moveX = Input.GetAxisRaw("Horizontal");
        float moveY = Input.GetAxisRaw("Vertical");
        moveDirection = new Vector2(moveX, moveY).normalized;
    }

    void Move()
    {
        rb.velocity = moveDirection * moveSpeed;
    }

    void FlipPlayer()
    {
        //starts w/ pos tranform > 0 and move left is neg < 0, move right is pos > 0

        if (moveDirection.x < 0 && playerTransform.localScale.x < 0)
        {
            //If player is pointing to the right, but moving left -> flip 
            playerTransform.localScale = new Vector3(-playerTransform.localScale.x, playerTransform.localScale.y, playerTransform.localScale.z);
        }
        else if (moveDirection.x > 0 && playerTransform.localScale.x > 0)
        {
            //If player is pointing to the left, but moving right -> flip
            playerTransform.localScale = new Vector3(-playerTransform.localScale.x, playerTransform.localScale.y, playerTransform.localScale.z);
        }
    }

    
}
